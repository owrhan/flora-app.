# Flora Marketing Mobile

This project wraps the Flora Marketing HTML application as an Android app using Capacitor.

## Build locally

```bash
npm install
npm run build:apk
```

The debug APK will be created at:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## Build with GitHub Actions

1. Create a private GitHub repository.
2. Upload all files from this folder to the repository.
3. Push to the `main` branch, or open **Actions → Build Flora APK → Run workflow**.
4. Download `flora-marketing-debug-apk` from the completed workflow run.

The current app data remains local to the device. It is not uploaded to GitHub.
